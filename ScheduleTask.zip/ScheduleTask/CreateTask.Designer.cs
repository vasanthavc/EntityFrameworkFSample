﻿namespace ScheduleTask
{
    partial class CreateTask
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.tskName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tskDescrition = new System.Windows.Forms.RichTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tskDate = new System.Windows.Forms.DateTimePicker();
            this.tskAssign = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbEmployee = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.taskBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cmbStartTime = new System.Windows.Forms.ComboBox();
            this.cmbEndTime = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.taskBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(65, 38);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            // 
            // tskName
            // 
            this.tskName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.taskBindingSource, "Name", true));
            this.tskName.Location = new System.Drawing.Point(223, 38);
            this.tskName.Margin = new System.Windows.Forms.Padding(4);
            this.tskName.Name = "tskName";
            this.tskName.Size = new System.Drawing.Size(265, 22);
            this.tskName.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(65, 118);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Descrition";
            // 
            // tskDescrition
            // 
            this.tskDescrition.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.taskBindingSource, "Description", true));
            this.tskDescrition.Location = new System.Drawing.Point(223, 114);
            this.tskDescrition.Margin = new System.Windows.Forms.Padding(4);
            this.tskDescrition.Name = "tskDescrition";
            this.tskDescrition.Size = new System.Drawing.Size(265, 117);
            this.tskDescrition.TabIndex = 4;
            this.tskDescrition.Text = "";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(65, 275);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Date";
            // 
            // tskDate
            // 
            this.tskDate.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.taskBindingSource, "Date", true, System.Windows.Forms.DataSourceUpdateMode.OnValidation, null, "D"));
            this.tskDate.Location = new System.Drawing.Point(223, 275);
            this.tskDate.Margin = new System.Windows.Forms.Padding(4);
            this.tskDate.Name = "tskDate";
            this.tskDate.Size = new System.Drawing.Size(265, 22);
            this.tskDate.TabIndex = 6;
            // 
            // tskAssign
            // 
            this.tskAssign.Location = new System.Drawing.Point(388, 578);
            this.tskAssign.Margin = new System.Windows.Forms.Padding(4);
            this.tskAssign.Name = "tskAssign";
            this.tskAssign.Size = new System.Drawing.Size(100, 28);
            this.tskAssign.TabIndex = 11;
            this.tskAssign.Text = "Assign Task";
            this.tskAssign.UseVisualStyleBackColor = true;
            this.tskAssign.Click += new System.EventHandler(this.tskAssign_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(65, 484);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "Assign To";
            // 
            // cmbEmployee
            // 
            this.cmbEmployee.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.taskBindingSource, "AssignedTo", true));
            this.cmbEmployee.FormattingEnabled = true;
            this.cmbEmployee.Location = new System.Drawing.Point(223, 484);
            this.cmbEmployee.Name = "cmbEmployee";
            this.cmbEmployee.Size = new System.Drawing.Size(121, 24);
            this.cmbEmployee.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(65, 355);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 17);
            this.label4.TabIndex = 14;
            this.label4.Text = "Start Time";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(65, 424);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 17);
            this.label5.TabIndex = 16;
            this.label5.Text = "End Time";
            // 
            // taskBindingSource
            // 
            this.taskBindingSource.DataSource = typeof(ScheduleTask.Task);
            // 
            // comboBox1
            // 
            this.cmbStartTime.FormattingEnabled = true;
            this.cmbStartTime.Location = new System.Drawing.Point(223, 355);
            this.cmbStartTime.Name = "cmbStartTime";
            this.cmbStartTime.Size = new System.Drawing.Size(121, 24);
            this.cmbStartTime.TabIndex = 19;
            // 
            // comboBox2
            // 
            this.cmbEndTime.FormattingEnabled = true;
            this.cmbEndTime.Location = new System.Drawing.Point(223, 424);
            this.cmbEndTime.Name = "cmbEndTime";
            this.cmbEndTime.Size = new System.Drawing.Size(121, 24);
            this.cmbEndTime.TabIndex = 20;
            // 
            // CreateTask
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(571, 669);
            this.Controls.Add(this.cmbEndTime);
            this.Controls.Add(this.cmbStartTime);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmbEmployee);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tskAssign);
            this.Controls.Add(this.tskDate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tskDescrition);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tskName);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "CreateTask";
            this.Text = "Schedule Task";
            ((System.ComponentModel.ISupportInitialize)(this.taskBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tskName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox tskDescrition;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker tskDate;
        private System.Windows.Forms.Button tskAssign;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbEmployee;
        private System.Windows.Forms.BindingSource taskBindingSource;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbStartTime;
        private System.Windows.Forms.ComboBox cmbEndTime;
    }
}