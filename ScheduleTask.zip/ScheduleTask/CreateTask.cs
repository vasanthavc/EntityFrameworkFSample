﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScheduleTask
{
    public partial class CreateTask : Form
    {
        public CreateTask()
        {
            InitializeComponent();            
            populateEmployee();
            populateTime();
        }
        private void populateEmployee()
        {
            cmbEmployee.DataSource = ScheduleTaskDBContext.getInstance().Employee.ToList();
            cmbEmployee.DisplayMember = "Name";
            cmbEmployee.ValueMember = "ID";
        }

        private void populateTime()
        {
            cmbStartTime.DataSource = ScheduleTaskDBContext.getInstance().Time.ToList();
            cmbStartTime.DisplayMember = "Value";
            cmbStartTime.ValueMember = "ID";
            cmbEndTime.DataSource = ScheduleTaskDBContext.getInstance().Time.ToList();
            cmbEndTime.DisplayMember = "Value";
            cmbEndTime.ValueMember = "ID";
        }

        private void tskAssign_Click(object sender, EventArgs e)
        {            
            int assignedTo = -1;            
            int.TryParse(cmbEmployee.SelectedValue.ToString(), out assignedTo);
            DateTime startDate = System.DateTime.MaxValue;
            DateTime endDate = System.DateTime.MaxValue;

            Task tsk = new Task
            {
                Name = tskName.Text,
                Description = tskDescrition.Text,
                Date = tskDate.Value.Date,
                StartTime = (int)cmbStartTime.SelectedValue,
                EndTime = (int)cmbEndTime.SelectedValue,
                AssignedTo = assignedTo               
            };
            if (!validateTaskExistsForEmployee(tsk))
            {
                MessageBox.Show("Task has been already assigned during this time");
                return;
            }

            if (!validateTaskHoursPerDay(tsk))
            {
                MessageBox.Show("You cannot assign task more than 8 hours per day for an employee");
                return;
            }

            if (!validateWorkingDaysInaWeek(tsk))
            {
                MessageBox.Show("You cannot assign task more than 5 days per week for an employee");
                return;
            }

            ScheduleTaskDBContext.getInstance().Task.Add(tsk);
            ScheduleTaskDBContext.getInstance().SaveChanges();
        }
        private bool validateTaskExistsForEmployee(Task newTask)
        {
            bool isValid = true;
            var result = ScheduleTaskDBContext.getInstance().Task.Where(a => a.AssignedTo == newTask.AssignedTo && a.Date == newTask.Date).ToList();
            isValid = result.Where(a => newTask.StartTime < a.EndTime && newTask.StartTime >= a.StartTime).Count() > 0 ? false : true;
            if (isValid)
            {
                isValid = result.Where(a => newTask.EndTime <= a.EndTime && newTask.EndTime > a.StartTime).Count() > 0 ? false : true;
            }
            return isValid;
        }

        private bool validateTaskHoursPerDay(Task newTask)
        {
            var result = ScheduleTaskDBContext.getInstance().Task.Where(a => a.AssignedTo == newTask.AssignedTo && a.Date == newTask.Date).ToList();
            return result.Count() > 0 ? result.Sum(a => (a.EndTime - a.StartTime)) + newTask.Effort <= 8 : newTask.EndTime - newTask.StartTime <= 8;
        }

        private bool validateWorkingDaysInaWeek(Task newTask)
        {
            int dow = (int)newTask.Date.DayOfWeek;
            DateTime startDate = newTask.Date.AddDays(-dow);
            DateTime endDate = startDate.AddDays(6);
            var result = ScheduleTaskDBContext.getInstance().Task.Where(a => a.AssignedTo == newTask.AssignedTo && a.Date >= startDate && a.Date <= endDate).ToList();
            if (result.Count() > 0) {
                var distinctValues = result.Select(a => a.Date).Distinct();
                if(!distinctValues.Contains(newTask.Date))
                {
                    return distinctValues.Count() <= 4;
                }
                return distinctValues.Count() <= 5;
            }
            return true;
        }
    }
}
