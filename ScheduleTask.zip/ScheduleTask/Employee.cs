﻿using System.ComponentModel.DataAnnotations;
using System.Data.Linq.Mapping;

namespace SQLiteWithEF
{
    [Table(Name = "Employee")]
    public class Employee
    {
        [Column(Name = "ID", IsDbGenerated = true, IsPrimaryKey = true, DbType = "INTEGER")]
        [Key]
        public int ID { get; set; }

        [Column(Name = "Name", DbType = "VARCHAR")]
        public string Name { get; set; }
    }
}