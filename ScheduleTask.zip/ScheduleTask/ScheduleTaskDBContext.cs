﻿using SQLiteWithEF;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Data.SQLite;
using System.Configuration;
using System;

namespace ScheduleTask
{
    class ScheduleTaskDBContext : DbContext
    {
        private static ScheduleTaskDBContext m_ScheduleTaskDBContext = null;
        public ScheduleTaskDBContext(string connectionString) :
            base(new SQLiteConnection()
            {
                ConnectionString = new SQLiteConnectionStringBuilder()
                {
                    DataSource = connectionString,
                    ForeignKeys = true
                }.ConnectionString
            }, true)
        {
        }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
            base.OnModelCreating(modelBuilder);
        }

        public DbSet<Employee> Employee { get; set; }
        public DbSet<Time> Time { get; set; }
        public DbSet<Task> Task { get; set; }
        public string DBConnectionString { get; set; }
        public static ScheduleTaskDBContext getInstance()
        {
            if (null == m_ScheduleTaskDBContext)
            {
                m_ScheduleTaskDBContext = new ScheduleTaskDBContext(AppDomain.CurrentDomain.BaseDirectory + ConfigurationManager.AppSettings["DBPath"].ToString());
            }
            return m_ScheduleTaskDBContext;
        }
    }
}
