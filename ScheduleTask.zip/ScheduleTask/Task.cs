﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Data.Linq.Mapping;

namespace ScheduleTask
{
    [Table(Name = "Task")]
    public class Task
    {
        [Column(Name = "ID", IsDbGenerated = true, IsPrimaryKey = true, DbType = "INTEGER")]
        [Key]
        public int ID
        {
            get;
            set;
        }

        [Column(Name = "AssignedTo", DbType = "INTEGER")]
        public int AssignedTo
        {
            get;
            set;
        }

        [Column(Name = "Name", DbType = "VARCHAR")]
        public string Name
        {
            get;
            set;
        }

        [Column(Name = "Description", DbType = "VARCHAR")]
        public string Description
        {
            get;
            set;
        }

        [Column(Name = "Date", DbType = "DATE")]
        public DateTime Date
        {
            get;
            set;
        }

        [Column(Name = "StartTime", DbType = "INTEGER")]
        public int StartTime
        {
            get;
            set;
        }

        [Column(Name = "EndTime", DbType = "INTEGER")]
        public int EndTime
        {
            get;
            set;
        }

        public int Effort
        {
            get
            {
                return EndTime - StartTime;
            }
        }
    }
}
