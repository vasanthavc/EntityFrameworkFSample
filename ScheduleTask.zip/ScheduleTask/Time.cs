﻿using System.ComponentModel.DataAnnotations;
using System.Data.Linq.Mapping;
namespace ScheduleTask
{
    [Table(Name = "Time")]
    public class Time
    {
        [Column(Name = "ID", IsDbGenerated = true, IsPrimaryKey = true, DbType = "INTEGER")]
        [Key]
        public int ID { get; set; }

        [Column(Name = "Value", DbType = "VARCHAR")]
        public string Value { get; set; }
    }
}